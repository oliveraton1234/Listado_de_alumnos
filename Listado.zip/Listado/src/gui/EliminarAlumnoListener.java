package gui;

public interface EliminarAlumnoListener {

    public void eliminarButtonCLick(String noControl);
    public void salirButtonClick();
}