package listado.Exepciones;

/**
 *
 * @author Megabit
 */
public class campoVacio extends Exception {

    
    public campoVacio() {
    }

 
    public campoVacio(String msg) {
        super(msg);
    }
}